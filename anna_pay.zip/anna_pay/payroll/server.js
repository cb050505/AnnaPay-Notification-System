const axios = require("axios");
const fs = require("fs");
const csv = require("csv-parser");
const express = require("express");
const multer = require("multer");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.static("public"));

// Database Connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "root",
    database: "payroll_db"
});

db.connect(err => {
    if (err) {
        console.log("Database connection failed");
    } else {
        console.log("Connected to database");
    }
});

// File Storage Configuration
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "uploads/");
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + "-" + file.originalname);
    }
});

const upload = multer({ storage: storage });

// Upload API
app.post("/upload", upload.single("salaryFile"), (req, res) => {
    const filename = req.file.filename;

    const sql = "INSERT INTO salary_uploads (filename) VALUES (?)";

    db.query(sql, [filename], (err, result) => {
        if (err) {
            return res.status(500).send("Database error");
        }
        res.send("File uploaded successfully");
    });
});

// Start Server
app.get("/", (req, res) => {
    res.sendFile(__dirname + "/public/uploads.html");
});
app.post("/proceed", (req, res) => {

    // Get latest uploaded file
    const sql = "SELECT filename FROM salary_uploads ORDER BY id DESC LIMIT 1";

    db.query(sql, (err, result) => {

        if (err || result.length === 0) {
            return res.status(500).json({ message: "No uploaded file found" });
        }

        const filePath = "uploads/" + result[0].filename;
        let employees = [];

        fs.createReadStream(filePath)
            .pipe(csv())
            .on("data", (row) => {
                employees.push(row);
            })
            .on("end", () => {

                employees.forEach(emp => {
                    console.log("Sending to bank:");
                    console.log("Account No:", emp.acc_no);
                    console.log("Salary:", emp.salary);
                    console.log("----------------------");
                });

                res.json({
                    message: "Salary credit request sent to bank successfully!",
                    totalEmployees: employees.length
                });

            })
            .on("error", (err) => {
                console.log(err);
                res.status(500).json({ message: "Error reading salary file" });
            });
    });
});
app.post("/sendNotifications", async (req, res) => {

    const filePath = path.join(__dirname, "uploads", "bank_update.csv");

    let employees = [];
    let successCount = 0;

    fs.createReadStream(filePath)
        .pipe(csv())
        .on("data", (row) => {
            console.log(row);
            employees.push(row);
        })
        .on("end", async () => {

            for (const emp of employees) {

                if (emp.transaction_status &&
    emp.transaction_status.toString().trim().toUpperCase() === "SUCCESS"
) {

                    const message = `Your a/c ${emp.acc_no} is credited by Rs.${emp.salary} on ${emp.transaction_date} ${emp.transaction_time} from Congruent Solutions (${emp.transaction_mode} ref no ${emp.transaction_id}).`;

                    try {
                        await axios.post("https://www.fast2sms.com/dev/bulkV2", {
                            route: "q",
                            message: message,
                            language: "english",
                            numbers: emp.mobile_no
                        }, {
                            headers: {
                                authorization: "n59vPbV140m72tjzEi0IB5CmFNHRFwEVX0WhGQDxRPU2AdvVne5pId6F2PaO",
                                "Content-Type": "application/json"
                            }
                        });

                        console.log("SMS sent to:", emp.mobile_no);
                        successCount++;

                    } catch (error) {
                        console.log("SMS failed for:", emp.mobile_no);
                    }
                }
            }

            res.json({
                message: "SMS process completed",
                totalSMSsent: successCount
            });

        })
        .on("error", (err) => {
            console.log("CSV Error:", err);
            res.status(500).json({ message: "Error reading bank update file" });
        });
});
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});